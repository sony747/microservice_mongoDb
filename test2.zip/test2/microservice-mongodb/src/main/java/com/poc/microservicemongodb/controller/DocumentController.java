package com.poc.microservicemongodb.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URLConnection;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.poc.microservicemongodb.service.DocumentService;

/**
 * @author Prashant_Parashar01
 *
 */
@RestController
public class DocumentController {

	private final DocumentService docService;
	
	@Autowired
	public DocumentController(DocumentService docService) {
		this.docService = docService;
	}
	
	@RequestMapping("/")
	public String home() {
		return "Welcome to Mongodb microservice! <br>" 
				+"a) Store document(\"C:\\Image\\Test.jpg\") by using /savedoc <br>"
				+"b) Get document by Id using /getdocs/{id}";
	}
	
	/*
	 * @RequestMapping("/getdocs") public List<Document> findAllDocuments(){ return
	 * docService.findAllDocuments(); }
	 * 
	 * @RequestMapping("/getdocs/{id}") public Optional<Document>
	 * findDocumentById(@PathVariable("id") String id){ return
	 * docService.findDocById(id); }
	 * 
	 * @RequestMapping("/savedoc") public String saveDocument() {
	 * 
	 * Document doc = new Document("Doc"+ Math.random(), "Test", "abc"); String
	 * filePath = "C:\\Image\\Test.jpg";
	 * 
	 * 
	 * byte[] fileContent; String encodedString = "";
	 * 
	 * try { fileContent = FileUtils.readFileToByteArray(new File(filePath));
	 * encodedString = Base64.getEncoder().encodeToString(fileContent); } catch
	 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * doc.setImage(encodedString); //System.out.println("Base64 string: "+
	 * encodedString);
	 * 
	 * docService.create(doc); return "Document is been saved successfully!"; }
	 */
	
	@RequestMapping("/savedoc")
	public String storeGridFSImg() {
		String filePath = "C:\\Image\\Test.jpg";
		try {
			File file = new File(filePath);
			InputStream inputstream = new FileInputStream(file);
					
			String contentType = URLConnection.guessContentTypeFromName(file.getName());
			
			System.out.println("content type is: "+ contentType); 
			
			
			  DBObject metadata = new BasicDBObject(); 
			  metadata.put("id", "Doc"+ Math.random()); 
			  metadata.put("title", "Test"); 
			  metadata.put("contentType",contentType);			 		
			
			ObjectId id = docService.storeGridFSImg(inputstream, "Test", contentType, metadata);
			System.out.println("Object id: "+ id.toString()); 
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Document is been saved successfully!";
	}
	
	@RequestMapping("/getdocs/{id}")
	public ResponseEntity<Resource> findGridFSDocs(@PathVariable("id") String id){
						
		GridFsResource resource = docService.findGridFSdocs(id);
		//ObjectMapper mapper = new ObjectMapper();
		//System.out.println(mapper.writeValueAsString(fs));	
		
		return ResponseEntity
			      .ok()
			      .contentType(MediaType.valueOf(resource.getContentType()))
			      .body(resource);
	}
}
