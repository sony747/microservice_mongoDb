package com.poc.microservicemongodb.service;

import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.gridfs.GridFsResource;

import com.mongodb.DBObject;
import com.poc.microservicemongodb.entity.Document;

/**
 * @author Prashant_Parashar01
 *
 */
public interface DocumentService {

	Document create(Document doc);
	
	List<Document> findAllDocuments();
	
	Optional<Document> findDocById(String id);
	
	ObjectId storeGridFSImg(InputStream inputstream, String filename, String contentType, DBObject metadata);
	
	GridFsResource findGridFSdocs(String id);
}
