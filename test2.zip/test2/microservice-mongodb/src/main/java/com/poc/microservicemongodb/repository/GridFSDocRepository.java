package com.poc.microservicemongodb.repository;

import java.io.InputStream;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.gridfs.GridFsResource;

import com.mongodb.DBObject;

public interface GridFSDocRepository {

	public ObjectId store(InputStream inputstream, String filename, String contentType, DBObject metadata);
	
	public GridFsResource findDoc(String id);
}
