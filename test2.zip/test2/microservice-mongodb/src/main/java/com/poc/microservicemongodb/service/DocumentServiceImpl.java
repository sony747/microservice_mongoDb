package com.poc.microservicemongodb.service;

import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.stereotype.Service;

import com.mongodb.DBObject;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.poc.microservicemongodb.entity.Document;
import com.poc.microservicemongodb.repository.DocumentRepository;
import com.poc.microservicemongodb.repository.GridFSDocRepository;

/**
 * @author Prashant_Parashar01
 *
 */
@Service
public class DocumentServiceImpl implements DocumentService {

	private final DocumentRepository docRepo;
	private final GridFSDocRepository gridFSdocRepo;
	
	@Autowired
	DocumentServiceImpl(DocumentRepository docRepo, GridFSDocRepository gridFSdocRepo){
		this.docRepo = docRepo;
		this.gridFSdocRepo = gridFSdocRepo;
	}
	
	@Override
	public Document create(Document doc) {
		// TODO Auto-generated method stub
		Document savedDoc = null;
		savedDoc = docRepo.save(doc);
		return savedDoc;
	}

	@Override
	public List<Document> findAllDocuments() {
		
		return docRepo.findAll();
	}

	@Override
	public Optional<Document> findDocById(String id) {
		return docRepo.findById(id);
	}

	@Override
	public ObjectId storeGridFSImg(InputStream inputstream, String filename, String contentType, DBObject metadata) {
		// TODO Auto-generated method stub
		return gridFSdocRepo.store(inputstream, filename, contentType, metadata); 
	}

	@Override
	public GridFsResource findGridFSdocs(String id) {
		return gridFSdocRepo.findDoc(id);
	}

}
