package com.poc.microservicemongodb.repository;

import java.io.InputStream;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsOperations;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Repository;

import com.mongodb.DBObject;
import com.mongodb.client.gridfs.model.GridFSFile;

//com.mongodb.client.gridfs.model.GridFSFile

@Repository
public class GridFSDocRepositoryImpl implements GridFSDocRepository {

	@Autowired
	GridFsTemplate gridFsTemplate;
	@Autowired
	GridFsOperations gridfsOperation;
	

	@Override
	public ObjectId store(InputStream inputstream, String filename, String contentType, DBObject metadata) {
		// TODO Auto-generated method stub
		return this.gridFsTemplate.store(inputstream, filename, contentType);
		//return this.gridFsTemplate.store(inputstream, filename, contentType, metadata);
	}

	@Override
	public GridFsResource findDoc(String id) {
		//List<GridFSFile> fileList = new ArrayList<GridFSFile>();
		//gridFsTemplate.find(new Query(Criteria.where("metadata.user").is("alex"))).into(gridFSFiles);
		GridFSFile file = gridFsTemplate.findOne(new Query(Criteria.where("_id").is(id)));
		return gridFsTemplate.getResource(file);
	}
	
	

}
