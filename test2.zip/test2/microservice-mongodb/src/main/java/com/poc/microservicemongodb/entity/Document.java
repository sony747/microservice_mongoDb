package com.poc.microservicemongodb.entity;

import org.springframework.data.annotation.Id;

import com.mongodb.gridfs.GridFS;

/**
 * @author Prashant_Parashar01
 *
 */

public class Document {
	
	@Id
	private String id;
	
	private String title;
	private String owner;
	private String image;
	private GridFS gfsImage;
	
	public Document(String id, String title, String owner) {
		this.id = id;
		this.title = title;
		this.owner = owner;
	}
	
	public Document() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public GridFS getGfsImage() {
		return gfsImage;
	}

	public void setGfsImage(GridFS gfsImage) {
		this.gfsImage = gfsImage;
	}
	
}
