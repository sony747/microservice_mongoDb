package com.poc.microservicemongodb.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.poc.microservicemongodb.entity.Document;

/**
 * @author Prashant_Parashar01
 *
 */
@Repository
public interface DocumentRepository extends MongoRepository<Document, String> {

	public Document save(Document doc);

	public List<Document> findAll();
	
	public Document findById(ObjectId id);
		
}
